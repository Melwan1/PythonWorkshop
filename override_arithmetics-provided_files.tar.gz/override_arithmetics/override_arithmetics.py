def add(x: int, y: int) -> int:
    pass

def sub(x: int, y: int) -> int:
    pass

def mul(x: int, y: int) -> int:
    pass

def div(x: int, y: int) -> int:
    pass

def mod(x: int, y: int) -> int:
    pass

def pow(x: int, y: int) -> int:
    pass

