def is_valid_login(login: str) -> bool:
    pass

def is_valid_password(password: str) -> bool:
    pass
