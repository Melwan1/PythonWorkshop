# Most frequent letters

In this exercise, you will learn to manipulate file streams.

## File tree

most_frequent_letters
├── most_frequent_letters.py
├── subject_most_frequent_letters.md
└── test_most_frequent_letters.py

## Help for this exercise

Check how to manipulate file streams: [click here](https://stackoverflow.com/questions/8011797/open-read-and-close-a-file-in-1-line-of-code).

Check how to build functions that take optional arguments: [click here](https://ioflood.com/blog/python-optional-arguments/).

Check how to manage exceptions in Python: [click here](https://docs.python.org/3/tutorial/errors.html).

## Instructions

In the file `most_frequent_letters.py`, you have to write the function `most_frequent_letters`. 

The goal of this function is to count each occurrence of each character, and return the most frequent of them across the file.

The function takes an argument of type `str` that represent the name of the file, and an **optional** argument named `limit` of type `int`. It returns a list of tuples, each tuple being :

- a capital letter (`"A"`, `"B"`, and so on),
- the number of occurrences of that letter (an integer).

---
**Be careful!**
There are a lot of small specifications you have to take into account:

1. If the file given by the file name does not exist, raise an exception of type `IOError`.

    Note : when the file does not exist, the `open` function will raise an exception of type `IOError`.

2. The limit argument is optional. If it is not provided, it is set by default to 26.

3. If the limit argument is provided and is not of type `int`, raise an exception of type `TypeError`.

4. If the limit argument is provided, is of type `int` and is outside of the bounds `[1, 26]` (bounds included), raise an exception of type `ValueError`.

    Note : raising exceptions will be tested, but the message they contain will not. Feel free to include a meaningful message when you write these exceptions.

5. When all checks are successful, you have to return a list of tuples, as specified above. The tuples have to be sorted by decreasing occurrences, and then by increasing letter order.

6. Any character that is not a letter is discarded, and not taken into account when calculating occurrences.

7. It does not matter whether a letter is capital or not. It appears capital when displaying calculations.

8. Accented letters do not count as letters.

9. You are only allowed to import one module: `sys`.
---

## Examples

When the file contains "GOODBYE my love 123" with the limit argument set to 5, the returned array of tuples is:

    `[("O", 3), ("E", 2), ("Y", 2), ("B", 1), ("D", 1)]`.

    If the limit argument is set to 12 with the same file, the returned array of tuples is: 

    `[("O", 3), ("E", 2), ("Y", 2), ("B", 1), ("D", 1), ("G", 1), ("L", 1), ("M", 1), ("V", 1), ("A", 0), ("C", 0), ("F", 0)]`.
