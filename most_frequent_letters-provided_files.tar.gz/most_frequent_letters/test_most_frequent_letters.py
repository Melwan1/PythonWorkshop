from most_frequent_letters import most_frequent_letters

import pytest

def assert_array_length(array, desired_length):
    assert len(array) == desired_length, f"Expected the returned array to have {desired_length} elements.\nGot: {len(array)} elements."

def create_file_with_content(filename, content):
    file = open(filename, "w")
    file.write(content)
    file.close()

def test_collections_forbidden():
    from modulefinder import ModuleFinder
    finder = ModuleFinder()
    finder.run_script("most_frequent_letters.py")
    assert len(finder.modules.items()) == 2, "Too many modules have been imported. You likely imported collections, which is forbidden for this exercise."

def test_valid_simple_with_limit_1():
    filename = "test.txt"
    content = "yes"
    create_file_with_content(filename, content)
    limit = 3
    frequencies = most_frequent_letters(filename, limit=limit)
    assert_array_length(frequencies, limit)
    result = [("E", 1), ("S", 1), ("Y", 1)]
    assert frequencies == result

def test_valid_simple_with_limit_2():
    filename = "test.txt"
    content = "yeesss"
    create_file_with_content(filename, content)
    limit = 3
    frequencies = most_frequent_letters(filename, limit=limit)
    assert_array_length(frequencies, limit)
    result = [("S", 3), ("E", 2), ("Y", 1)]
    assert frequencies == result

def test_valid_simple_with_limit_3():
    filename = "test.txt"
    content = "ohh no"
    create_file_with_content(filename, content)
    limit = 3
    frequencies = most_frequent_letters(filename, limit=limit)
    assert_array_length(frequencies, limit)
    result = [("H", 2), ("O", 2), ("N", 1)]
    assert frequencies == result

def test_valid_case_mix_with_limit_1():
    filename = "test.txt"
    content = "AzEerTyYYYtTtREzAAaa"
    create_file_with_content(filename, content)
    limit = 7
    frequencies = most_frequent_letters(filename, limit=limit)
    assert_array_length(frequencies, limit)
    result = [("A", 5), ("T", 4), ("Y", 4), ("E", 3), ("R", 2), ("Z", 2), ("B", 0)]
    assert frequencies == result

def test_valid_case_mix_with_limit_2():
    filename = "test.txt"
    content = "AzEerTyYYYtTtREzAAaa"
    create_file_with_content(filename, content)
    limit = 4
    frequencies = most_frequent_letters(filename, limit=limit)
    assert_array_length(frequencies, limit)
    result = [("A", 5), ("T", 4), ("Y", 4), ("E", 3)]
    assert frequencies == result


def test_valid_case_mix_without_limit_1():
    filename = "test.txt"
    content = "AzEerTyYYYtTtREzAAaa"
    create_file_with_content(filename, content)
    frequencies = most_frequent_letters(filename)
    assert_array_length(frequencies, 26)
    result = [("A", 5), ("T", 4), ("Y", 4), ("E", 3), ("R", 2), ("Z", 2), ("B", 0), ("C", 0), ("D", 0), ("F", 0), ("G", 0), ("H", 0), ("I", 0), ("J", 0), ("K", 0), ("L", 0), ("M", 0), ("N", 0), ("O", 0), ("P", 0), ("Q", 0), ("S", 0), ("U", 0), ("V", 0), ("W", 0), ("X", 0)]
    assert frequencies == result

def test_valid_special_characters_1():
    filename = "test.txt"
    content = "a*a"
    create_file_with_content(filename, content)
    limit = 2
    frequencies = most_frequent_letters(filename, limit=limit)
    assert_array_length(frequencies, limit)
    result = [("A", 2), ("B", 0)]
    assert frequencies == result

def test_valid_special_characters_2():
    filename = "test.txt"
    content = "azertyuiopqsdfghjklmwxcvbnee\"\'(§è!çà)-^$ù`,;:=\\`"
    create_file_with_content(filename, content)
    limit = 3
    frequencies = most_frequent_letters(filename, limit=limit)
    assert_array_length(frequencies, limit)
    result = [("E", 3), ("A", 1), ("B", 1)]
    assert frequencies == result

def test_valid_big_file():
    filename = "test.txt"
    content = "A" * 500 + "B" * 400 + "C" * 300 + "D" * 200 + "E" * 100 \
            + "a" * 500 + "b" * 400 + "c" * 300 + "d" * 200 + "e" * 100 \
            + "'" * 999
    create_file_with_content(filename, content)
    limit = 6
    frequencies = most_frequent_letters(filename, limit=limit)
    assert_array_length(frequencies, limit)
    result = [("A", 1000), ("B", 800), ("C", 600), ("D", 400), ("E", 200), ("F", 0)]
    assert frequencies == result

def test_valid_same_frequency():
    filename = "test.txt"
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    content = letters + letters.lower()
    limit = 26
    create_file_with_content(filename, content)
    frequencies = most_frequent_letters(filename)
    assert_array_length(frequencies, limit)
    result = []
    for letter in letters:
        result.append((letter, 2))
    assert frequencies == result


def test_inexistent_file_1():
    filename = "inexistent.txt"
    with pytest.raises(IOError) as e_info:
        most_frequent_letters(filename)

def test_inexistent_file_2():
    filename = ""
    with pytest.raises(IOError) as e_info:
        most_frequent_letters(filename)

def test_invalid_limit_type_float():
    filename = "test.txt"
    with pytest.raises(TypeError) as e_info:
        most_frequent_letters(filename, 4.7)
    
def test_invalid_limit_type_string():
    filename = "test.txt"
    with pytest.raises(TypeError) as e_info:
        most_frequent_letters(filename, "hello")

def test_invalid_limit_type_none():
    filename = "test.txt"
    with pytest.raises(TypeError) as e_info:
        most_frequent_letters(filename, None)

def test_invalid_limit_value_small():
    filename = "test.txt"
    limit = 0
    with pytest.raises(ValueError) as e_info:
        most_frequent_letters(filename, limit=limit)

def test_invalid_limit_value_negative():
    filename = "test.txt"
    limit = -42
    with pytest.raises(ValueError) as e_info:
        most_frequent_letters(filename, limit=limit)

def test_invalid_limit_value_big():
    filename = "test.txt"
    limit = 27
    with pytest.raises(ValueError) as e_info:
        most_frequent_letters(filename, limit=limit)

def test_invalid_limit_value_very_big():
    filename = "test.txt"
    limit = 999999
    with pytest.raises(ValueError) as e_info:
        most_frequent_letters(filename, limit=limit)
    import os
    os.remove("test.txt")

